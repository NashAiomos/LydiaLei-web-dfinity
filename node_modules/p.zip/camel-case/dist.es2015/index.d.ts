import { Options } from "pascal-case";
export { Options };
export declare function camelCaseTransform(input: string, index: number): string;
export declare function camelCaseTransformMerge(input: string, index: number): string;
export declare function camelCase(input: string, options?: Options): string;
